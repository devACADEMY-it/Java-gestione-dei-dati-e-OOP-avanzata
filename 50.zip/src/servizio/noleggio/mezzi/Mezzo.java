package servizio.noleggio.mezzi;

public abstract class Mezzo implements Noleggiabile{
	protected String targa;
	
	protected Mezzo(String targa) {
		this.targa=targa;
	}
	
	@Override
	public String toString() {
		return this.getClass().getSimpleName()+" targato "+targa;
	}
	
	public String getTarga() {
		return targa;
	}
}
