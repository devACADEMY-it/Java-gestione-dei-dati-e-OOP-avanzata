import java.util.*;

class Libro{
	private String titolo;
	private int pagine;
	private float prezzo;
	
	Libro(String titolo, int pagine, float prezzo){
		this.titolo=titolo;
		this.pagine=pagine;
		this.prezzo=prezzo;
	}
	
	public int getPagine() {
		return pagine;
	}
	
	public float getPrezzo() {
		return prezzo;
	}
	
	@Override
	public String toString() {
		return titolo+" ("+pagine+" pagine), "+prezzo+" euro";
	}
	
}

public class Main {

	public static void main(String[] args) {
		ArrayList<Libro> libri=new ArrayList<Libro>();
		libri.add(new Libro("Manuale giardinaggio", 450, 25));
		libri.add(new Libro("Piante", 670, 52));
		libri.add(new Libro("Avventure nello spazio", 125, 12));
		libri.add(new Libro("Pirati", 320, 16));
		
		libri.stream()
		.filter(l->l.getPagine()<=350 && l.getPrezzo()<=15.0)
		.forEach(System.out::println);
	}

}
