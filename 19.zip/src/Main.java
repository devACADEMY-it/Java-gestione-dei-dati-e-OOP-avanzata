public class Main {

	public static void main(String[] args) {
		//StringBuilder sb=new StringBuilder();
		StringBuffer sb=new StringBuffer();
		sb.append("Ciao, ");
		sb.append("mi chiamo Simone e sono un ");
		sb.append("programmatore");
		String frase=sb.toString();
		System.out.println(frase);
	}

}
