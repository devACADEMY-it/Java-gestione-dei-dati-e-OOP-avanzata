package servizio.noleggio.mezzi;

public interface Noleggiabile {
	void noleggio();
}
