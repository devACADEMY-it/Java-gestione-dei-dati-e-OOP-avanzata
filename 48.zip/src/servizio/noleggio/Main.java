package servizio.noleggio;
import servizio.noleggio.mezzi.*;

public class Main {

	public static void main(String[] args) {
		Scooter scooter=new Scooter("AB123");
		Monopattino monopattino=new Monopattino("XY456");
		System.out.println(scooter);
		System.out.println(monopattino);
		
		System.out.println();
		
		scooter.noleggio();
		monopattino.noleggio();
	}

}
