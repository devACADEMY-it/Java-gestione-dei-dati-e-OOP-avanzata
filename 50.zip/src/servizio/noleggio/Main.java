package servizio.noleggio;
import servizio.noleggio.mezzi.*;
import servizio.noleggio.mezzi.dati.CaricamentoDati;

public class Main {

	public static void main(String[] args) {
		ServizioNoleggio servizio=new ServizioNoleggio("parco-mezzi.txt");
		servizio.noleggioScooter();
		servizio.noleggioScooter();
		servizio.noleggioScooter();
		servizio.noleggioScooter();
		servizio.noleggioScooter();
		servizio.restituisciMezzo("XY456");
		servizio.noleggioScooter();
		servizio.noleggioScooter();
		
		System.out.println();
		
		servizio.noleggioMonopattino();
		servizio.noleggioMonopattino();
		servizio.restituisciMezzo("ZZ008");
		servizio.noleggioMonopattino();
		servizio.noleggioMonopattino();
	}

}
