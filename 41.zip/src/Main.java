import java.io.*;

public class Main {

	public static void main(String[] args) {
		try(PrintStream printStream=new PrintStream("stampa.txt")){
			printStream.println("Ciao mondo!");
			printStream.println("bla bla bla");
			printStream.println("ultima riga!");
			System.out.println("Fine del salvataggio su file!");
		}
		catch(IOException io) {
			System.out.println(io.getMessage());
		}
	}
}
