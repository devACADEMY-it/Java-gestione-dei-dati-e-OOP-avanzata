class PacchettoMultimedia<T extends Multimedia, Z extends Multimedia>{
	private T multimediale1;
	private Z multimediale2;
	private String nomePacchetto;
	
	PacchettoMultimedia(String nomePacchetto, T multimediale1, Z multimediale2){
		this.nomePacchetto=nomePacchetto;
		this.multimediale1=multimediale1;
		this.multimediale2=multimediale2;
	}
	
	void stampaDescrizione() {
		System.out.println(nomePacchetto+":");
		System.out.println(multimediale1);
		System.out.println(multimediale2);
		System.out.println();
	}
	
	
}

class Multimedia{
	protected String titolo;
}

class Libro extends Multimedia{
	Libro(String titolo){
		this.titolo=titolo;
	}
	
	@Override
	public String toString() {
		return "Libro: "+titolo;
	}
}

class DVD extends Multimedia{
	DVD(String titolo){
		this.titolo=titolo;
	}
	
	@Override
	public String toString() {
		return "DVD: "+titolo;
	}
}

public class Main {

	public static void main(String[] args) {
		PacchettoMultimedia<Libro, DVD> pacchettoNatale=new PacchettoMultimedia<Libro,DVD>(
				    "Regalo di Natale",
					new Libro("Babbo Natale"),
					new DVD("Canti di Natale")
				);
		PacchettoMultimedia<Libro, Libro> pacchettoPrimavera=new PacchettoMultimedia<Libro,Libro>(
			    "Primavera",
				new Libro("Giardinaggio"),
				new Libro("Primavera")
			);
		pacchettoNatale.stampaDescrizione();
		pacchettoPrimavera.stampaDescrizione();
	}

}
