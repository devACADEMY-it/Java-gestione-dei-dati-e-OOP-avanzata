import java.io.*;

public class Main {

	public static void main(String[] args) {
		  
		String messaggio="Messaggio da salvare\n su file";
		try(BufferedWriter writer=
				new BufferedWriter(new FileWriter("datisalvati.txt"))){
			writer.write(messaggio);
		}
		catch(IOException io) {
			System.out.println(io.getMessage());
		}
	}
}
