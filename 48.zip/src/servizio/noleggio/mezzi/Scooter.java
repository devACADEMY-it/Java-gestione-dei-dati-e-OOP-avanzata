package servizio.noleggio.mezzi;

public class Scooter extends Mezzo {

	public Scooter(String targa) {
		super(targa);
	}

	@Override
	public void noleggio() {
		System.out.println("Noleggio Scooter "+targa);
	}

}
