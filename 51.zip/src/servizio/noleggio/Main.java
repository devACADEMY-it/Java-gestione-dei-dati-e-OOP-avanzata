package servizio.noleggio;
import servizio.noleggio.mezzi.*;
import java.util.*;

public class Main {
	private static void menu() {
		System.out.println("\nOperazioni disponibili");
		System.out.println("1 - noleggia uno scooter");
		System.out.println("2 - noleggia un monopattino");
		System.out.println("3 - restituisci un mezzo");
		System.out.println("0 - esci dal programma");
		System.out.println("\nCosa si vuole fare?");
	}
	
	public static void main(String[] args) {
		ServizioNoleggio servizio=new ServizioNoleggio("parco-mezzi.txt");
		try(Scanner risposta=new Scanner(System.in)){
			while(true) {
				menu();
				int scelta=risposta.nextInt();
				switch(scelta) {
				    case 1:
				    	servizio.noleggioScooter();
				    	break;
				    case 2:
				    	servizio.noleggioMonopattino();
				    	break;
				    case 3:
				    	System.out.println("Targa ?");
				    	Scanner riconsegna=new Scanner(System.in);
				    	servizio.restituisciMezzo(riconsegna.next());
				    	break;
				    case 0:
				    	System.out.println("Grazie per aver usato il nostro servizio");
				    	System.exit(0);
				}
			}
		}
	}

}
