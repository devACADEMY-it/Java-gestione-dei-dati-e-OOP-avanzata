import java.util.ArrayList;

interface Noleggiabile{
	
	static String elencoPuntiVendita() {
		return "Punti vendita:\n"
			   +"- Centro commerciale Airone"
			   +"- Centro commerciale Giraffa";
	}
	
	void noleggio();
}

class Monopattino implements Noleggiabile{
	
	public void noleggio() {
		System.out.println("Monopattino 30 euro/g");
	}
}

class Scooter implements Noleggiabile{
	
    public void noleggio() {
    	System.out.println("Scooter 100 euro/g");
	}
    
    public String restituisciTarga() {
    	return "ABC123";
	}
}

public class Main {

	public static void main(String[] args) {
		ArrayList<Noleggiabile> mezzi=new ArrayList<Noleggiabile>();
		mezzi.add(new Scooter());
		mezzi.add(new Monopattino());
		mezzi.add(new Scooter());
		mezzi.add(new Monopattino());
		mezzi.add(new Monopattino());
		mezzi.add(new Monopattino());
		mezzi.add(new Monopattino());
		
		for (Noleggiabile mezzo: mezzi)
			mezzo.noleggio();
	}

}
