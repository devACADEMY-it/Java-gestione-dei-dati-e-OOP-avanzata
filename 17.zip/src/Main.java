import java.util.*;

public class Main {

	public static void main(String[] args) {
		Set<String> follower=new HashSet<String>();
		Set<String> following=new HashSet<String>();
		
		follower.add("flavio81");
		follower.add("silvio75");
		follower.add("enea00");
		follower.add("vane81");
		
		following.add("flavio81");
		following.add("silvio75");
		following.add("superstar");
		following.add("roma01");
		
		Set<String> unione=new HashSet<String>(follower);
		unione.addAll(following);
		for (String contatto: unione) {
			System.out.println(">> "+contatto);
		}
		System.out.println();
		Set<String> followingNonRicambiato=new HashSet<String>(following);
		followingNonRicambiato.removeAll(follower);
		for (String contatto: followingNonRicambiato) {
			System.out.println(">> "+contatto);
		}
		
	}

}
