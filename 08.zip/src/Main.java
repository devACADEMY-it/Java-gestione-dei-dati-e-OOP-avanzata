class GestoreDati<T>{
	private T dati;
	
	GestoreDati(T dati){
		this.dati=dati;
	}
	
	void stampa() {
		System.out.println(dati);
	}
}

class Persona{
	private String nome;
	private String cognome;
	
	Persona(String nome, String cognome){
		this.nome=nome;
		this.cognome=cognome;
	}
	
	@Override
	public String toString() {
		return "Ciao, sono "+nome+" "+cognome;
	}
}

public class Main {

	public static void main(String[] args) {
		GestoreDati<String> gestoreStringhe=
				new GestoreDati<String>("Buongiorno a tutti!");
		
		Persona p=new Persona("Aldo","Rossi");
		GestoreDati<Persona> gestorePersone=
				new GestoreDati<Persona>(p);
		gestoreStringhe.stampa();
		gestorePersone.stampa();
	}

}
