interface Vendibile{
	void vendiProdotto();
}

interface Noleggiabile{
	void noleggiaProdotto();
}

class Prodotto implements Vendibile, Noleggiabile{

	private String descrizione;
	private float prezzoVendita;
	private float prezzoNoleggio;
	
	Prodotto(String descrizione, float prezzoVendita, float prezzoNoleggio){
		this.descrizione=descrizione;
		this.prezzoNoleggio=prezzoNoleggio;
		this.prezzoVendita=prezzoVendita;
	}
	
	@Override
	public void noleggiaProdotto() {
		System.out.println("Il prodotto è stato noleggiato a "+prezzoNoleggio+" euro");
	}

	@Override
	public void vendiProdotto() {
		System.out.println("Il prodotto è stato venduto a "+prezzoVendita+" euro");
	}
	
}


public class Main {

	public static void main(String[] args) {
		Prodotto prodotto=new Prodotto("Monopattino", 5000, 50);
		prodotto.vendiProdotto();
		prodotto.noleggiaProdotto();
	}

}
