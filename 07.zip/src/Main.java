class GestoreDati<T>{
	private T dati;
	
	GestoreDati(T dati){
		this.dati=dati;
	}
	
	void stampa() {
		System.out.println(dati);
	}
}

public class Main {

	public static void main(String[] args) {
		GestoreDati<String> gestoreStringhe=
				new GestoreDati<String>("Buongiorno a tutti!");
		gestoreStringhe.stampa();
	}

}
