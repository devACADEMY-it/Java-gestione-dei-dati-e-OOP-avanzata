import java.util.*;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		/*ArrayList<String> nomi=new ArrayList<String>();
		nomi.add("Marco");
		nomi.add("Giada");
		nomi.add("Alessandro");
		nomi.add("Ivan");
		nomi.add("Ida");
		nomi.add("Ivo");
		nomi.add("Francesco");
		
		nomi.stream()*/
		Stream<String> stream=Stream.of("Marco", "Giovanni", "Ida", "Paolo","Ivo");
		
		stream.filter(s->s.length()>=5)
		.sorted()
		.forEach(System.out::println);
	}

}
