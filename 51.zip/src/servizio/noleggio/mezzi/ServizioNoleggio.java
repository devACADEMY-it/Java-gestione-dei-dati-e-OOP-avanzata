package servizio.noleggio.mezzi;
import java.util.*;
import servizio.noleggio.mezzi.dati.*;

public class ServizioNoleggio {
	private List<Scooter> scooter;
	private List<Monopattino> monopattini;
	private HashMap<String, Noleggiabile> noleggiati=new HashMap<String, Noleggiabile>();
	
	public ServizioNoleggio(String nomefile) {
		CaricamentoDati caricamento=new CaricamentoDati(nomefile);
		scooter=new ArrayList<Scooter>();
		monopattini=new ArrayList<Monopattino>();
		
		List<Noleggiabile> mezzi=caricamento.mezzi();
		mezzi.stream().forEach((Noleggiabile n)->{
			if (n.getClass()==Scooter.class)
				scooter.add((Scooter) n);
			else
				monopattini.add((Monopattino) n);
		});
	}
	
	public void noleggioScooter() {
		if (scooter.isEmpty())
			System.out.println("Scooter non disponibili");
		else {
			Scooter daNoleggiare=scooter.get(0);
			daNoleggiare.noleggio();
			noleggiati.put(daNoleggiare.getTarga(), daNoleggiare);
			scooter.remove(daNoleggiare);
		}
	}
	
	public void noleggioMonopattino() {
		if (monopattini.isEmpty())
			System.out.println("Monopattini non disponibili");
		else {
			Monopattino daNoleggiare=monopattini.get(0);
			daNoleggiare.noleggio();
			noleggiati.put(daNoleggiare.getTarga(), daNoleggiare);
			monopattini.remove(daNoleggiare);
		}
	}
	
	public void restituisciMezzo(String targa) {
		if (noleggiati.containsKey(targa))
		{
			Noleggiabile noleggiato=noleggiati.get(targa);
			if (noleggiato.getClass()==Scooter.class)
				scooter.add((Scooter) noleggiato);
			else
				monopattini.add((Monopattino) noleggiato);
			noleggiati.remove(targa);
		}
		else
			System.out.println("Targa errata "+targa);
	}
}
