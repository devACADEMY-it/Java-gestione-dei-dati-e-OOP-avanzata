interface Vendibile{
	
	default void vendiProdotto(){
		System.out.println("Venduto a 500 euro");
	}
}

class Prodotto implements Vendibile{
	
	/*@Override
	public void vendiProdotto() {
		System.out.println("Venduto a 1000 euro");
	}*/
	
}

public class Main {

	public static void main(String[] args) {
		Prodotto prodotto = new Prodotto();
		prodotto.vendiProdotto();
	}

}
