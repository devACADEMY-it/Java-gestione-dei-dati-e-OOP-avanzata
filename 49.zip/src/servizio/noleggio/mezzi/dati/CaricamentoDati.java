package servizio.noleggio.mezzi.dati;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import servizio.noleggio.mezzi.*;

public class CaricamentoDati {
	private ArrayList<Noleggiabile> mezzi=new ArrayList<Noleggiabile>();
	
	public List<Noleggiabile> mezzi(){
		return mezzi;
	}
	
	private void elaboraStringa(String stringa) {
		// Scooter AB123 ... Monopattino XY456
		Pattern pattern=Pattern.compile("^(Scooter|Monopattino) [A-Z]{2}[0-9]{3}$");
		Matcher match=pattern.matcher(stringa);
		if (match.find()) {
			String[] porzioni=stringa.split(" ");
			if (porzioni[0].equals("Scooter"))
				mezzi.add(new Scooter(porzioni[1]));
			else
				mezzi.add(new Monopattino(porzioni[1]));
		}
	}
	
	public CaricamentoDati(String nomefile) {
		try {
			List<String> righe=Files.readAllLines(Path.of(nomefile));
			for (String riga: righe)
				elaboraStringa(riga);
		}
		catch(IOException io) {
			System.out.println(io.getMessage());
		}
	}
}
