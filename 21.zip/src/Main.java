import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {

	public static void main(String[] args) {
		LocalDate d=LocalDate.of(1980,1,25);
		System.out.println(d.isAfter(LocalDate.now()));
		System.out.println(d.isBefore(LocalDate.now()));
		
		LocalDate res=d.minusDays(40);
		LocalDate res2=d.plusYears(1);
		System.out.println(res);
		System.out.println(res2);
		System.out.println(Period.between(res2, res));
		
		LocalTime dt1=LocalTime.of(11,56,11);
		LocalTime dt2=LocalTime.of(13,15,14);
		System.out.println(Duration.between(dt1, dt2).getSeconds());
		
	}

}
