import java.util.*;

class Programmatore{
	private String nome;
	private int votoJava;
	private int votoPython;
	
	public Programmatore(String nome, int votoJava, int votoPython) {
		this.nome=nome;
		this.votoJava=votoJava;
		this.votoPython=votoPython;
	}
	
	public float valutazioneMedia() {
		return (votoJava+votoPython)/2.0f;
	}
	
	@Override
	public String toString() {
		return nome+" voto="+valutazioneMedia();
	}
}

public class Main {

	public static void main(String[] args) {
		ArrayList<Programmatore> programmatori=new ArrayList<Programmatore>();
		programmatori.add(new Programmatore("Mario", 8, 9));
		programmatori.add(new Programmatore("Luca", 7, 7));
		programmatori.add(new Programmatore("Marco", 6, 4));
		programmatori.add(new Programmatore("Giovanni", 8, 5));
		programmatori.add(new Programmatore("Giuseppe", 9, 6));
		
		programmatori.stream()
		.filter(p->p.valutazioneMedia()>=7)
		.sorted((p1,p2) -> -Float.compare(p1.valutazioneMedia(), p2.valutazioneMedia()))
		.forEach(System.out::println);
		
	}

}
