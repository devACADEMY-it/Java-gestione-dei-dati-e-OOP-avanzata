import java.util.regex.Pattern;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		Pattern pattern=Pattern.compile("^[A-Z]{5}-?[0-9]{2}$");
		Matcher match=pattern.matcher("GTHaR-56");
		
		
		List<String> codici=Arrays.asList("GTHaR-56",
				"GTHAR-56","GTHGR56","ergherighHTYHR-56","GTHAR-5556");
		for (String codice: codici)
			System.out.println(codice+" : "+pattern.matcher(codice).find());
	}

}
