import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		try(Scanner risposta=new Scanner(System.in)){
			System.out.println("Dammi un numero ");
			int numero=risposta.nextInt();
			try(PrintStream printStream=new PrintStream("multipli.txt")){
				System.setOut(printStream);
				for (int i=1; i<=10; i++)
					System.out.println(i*numero);
			}
			catch(IOException io) {
				// gestione dell'errore
			}
		}
	}
}
