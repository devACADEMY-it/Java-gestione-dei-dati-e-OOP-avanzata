class GestoreDati<T extends Persona>{
	private T dati;
	
	GestoreDati(T dati){
		this.dati=dati;
	}
	
	void stampa() {
		System.out.println(dati);
	}
}

class Persona{
	private String nome;
	private String cognome;
	
	Persona(String nome, String cognome){
		this.nome=nome;
		this.cognome=cognome;
	}
	
	@Override
	public String toString() {
		return "Ciao, sono "+nome+" "+cognome;
	}
}

class Studente extends Persona{
	private String corso;
	
	Studente(String nome, String cognome, String corso){
		super(nome, cognome);
		this.corso=corso;
	}
	
	@Override
	public String toString() {
		return "Ciao, studio "+corso;
	}
}

public class Main {

	public static void main(String[] args) {
		Persona p=new Persona("Aldo","Rossi");
		GestoreDati<Persona> gestorePersone=
				new GestoreDati<Persona>(p);
		
		Studente s=new Studente("Ivo","Neri","Storia");
		GestoreDati<Studente> gestoreStudenti=
				new GestoreDati<Studente>(s);
		
		gestorePersone.stampa();
		gestoreStudenti.stampa();
	}

}
