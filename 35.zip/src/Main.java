enum Stato{ON, OFF};

class Sistema{
	private String amministratore;
	private Stato statoSistema;
	
	public String getAmministratore() {
		return amministratore;
	}
	public void setAmministratore(String amministratore) {
		this.amministratore = amministratore;
	}
	public Stato getStatoSistema() {
		return statoSistema;
	}
	public void setStatoSistema(Stato statoSistema) {
		this.statoSistema = statoSistema;
	}
	
	public Sistema(String amministratore, Stato statoSistema) {
		this.amministratore = amministratore;
		this.statoSistema = statoSistema;
	}
	
}

public class Main {

	public static void main(String[] args) {
		
		Sistema calcolatore=new Sistema("luke89", Stato.OFF);
		calcolatore.setStatoSistema(Stato.ON);
		
		switch(calcolatore.getStatoSistema()) {
		     case ON:
		    	 System.out.println("Il sistema sta funzionando!");
		    	 break;
		     case OFF:
		    	 System.out.println("Il sistema non funziona...");
		    	 System.out.println("Chiamare subito "+calcolatore.getAmministratore());
		}
		
	}

}
