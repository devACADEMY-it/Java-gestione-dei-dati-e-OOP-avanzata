package servizio.noleggio.mezzi;

public class Monopattino extends Mezzo{

	public Monopattino(String targa) {
		super(targa);
	}

	@Override
	public void noleggio() {
		System.out.println("Noleggio monopattino "+targa);
	}

}
