import java.util.*;

public class Main {

	public static void main(String[] args) {
		Set<String> frutti=new LinkedHashSet<String>();
		frutti.add("banana");
		frutti.add("mela");
		frutti.add("pera");
		frutti.add("kiwi");
		frutti.add("banana");
		frutti.add("anguria");
		frutti.add("mela");
		
		System.out.println("Il Set contiene "+frutti.size()+" elementi");
		for (String frutto: frutti)
			System.out.println(">> "+frutto);
	}

}
