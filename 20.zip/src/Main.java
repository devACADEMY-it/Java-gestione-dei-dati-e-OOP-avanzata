import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {

	public static void main(String[] args) {
		LocalDate d=LocalDate.of(2024, 1, 12);
		System.out.println(d);
		
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println(d.format(myFormat));
		
		LocalTime t=LocalTime.of(18,25,34);
		System.out.println(t);
		
		DateTimeFormatter myTimeFormat=DateTimeFormatter.ofPattern("HH:mm:ss");
		System.out.println(t.format(myTimeFormat));
		
		LocalDateTime dt=LocalDateTime.of(2024, 1, 12,18,25,34);
		System.out.println(dt);
		
		DateTimeFormatter myDateTimeFormat=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		System.out.println(dt.format(myDateTimeFormat));
	}

}
