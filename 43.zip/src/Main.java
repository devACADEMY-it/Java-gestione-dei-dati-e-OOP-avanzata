import java.io.*;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		try(Scanner scan=new Scanner(System.in)){
			System.out.println("Come ti chiami? ");
			String nome=scan.nextLine();
			System.out.println("Ciao, "+nome);
		}
	}
}
