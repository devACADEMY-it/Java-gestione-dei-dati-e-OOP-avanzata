interface GeneratoreTabelline{
	void stampa(int numero);
}

public class Main {

	public static void main(String[] args) {
		
		GeneratoreTabelline generatore=(numero)->{
			for (int i=1; i<=10; i++)
				System.out.println(numero+" X "+i+" = "+(i*numero));
		};
		
		generatore.stampa(5);
	}

}
