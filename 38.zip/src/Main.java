import java.util.ArrayList;

record Prodotto(String descrizione, float prezzo) {};

record Acquisto(Prodotto prodotto, int quantita) {
	float costo() {
		return prodotto.prezzo()*quantita;
	}
};

class Carrello{
	private ArrayList<Acquisto> carrello=new ArrayList<Acquisto>();
	
	void nuovoAcquisto(Prodotto prodotto, int quantita) {
		carrello.add(new Acquisto(prodotto, quantita));
	}
	
	float calcolaTotale() {
		float totale=0;
		for(Acquisto a:carrello) {
			totale+=a.costo();
		}
		return totale;
	}
	
	@Override
	public String toString() {
		return "Totale: "+calcolaTotale()+" euro";
	}
}

public class Main {

	public static void main(String[] args) {
		Prodotto pettine=new Prodotto("Pettine", 2);
		Prodotto penna=new Prodotto("Penna", 1);
		
		Carrello carrello=new Carrello();
		carrello.nuovoAcquisto(pettine, 2);
		carrello.nuovoAcquisto(penna, 5);
		
		System.out.println(carrello);
	}

}
