package servizio.noleggio;
import servizio.noleggio.mezzi.*;
import servizio.noleggio.mezzi.dati.CaricamentoDati;

public class Main {

	public static void main(String[] args) {
		CaricamentoDati caricamento=new CaricamentoDati("parco-mezzi.txt");
		caricamento.mezzi().stream().forEach(System.out::println);
	}

}
