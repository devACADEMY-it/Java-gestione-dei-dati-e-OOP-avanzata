import java.io.*;

public class Main {

	public static void main(String[] args) {
		
		try(PrintStream printStream=new PrintStream("printstream.txt")){
			PrintStream salvato=System.out;
			
			System.setOut(printStream);
			
			System.out.println("Ciao mondo!");
			System.out.println("Stampiamo dati");
			System.out.println("finito di stampare");
			
			System.setOut(salvato);
			System.out.println("Siamo ancora su file?");
			System.out.println("Forse no...tornati su console");
		}
		catch(IOException io) {
			// gestione dell'eccezione
		}
		
	}
}
