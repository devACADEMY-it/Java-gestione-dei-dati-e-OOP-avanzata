sealed class Libro permits Manuale, Dizionario, Romanzo{
	
}

sealed class Manuale extends Libro permits ManualeIllustrato{}

final ManualeIllustrato extends Manuale{}

non-sealed class Dizionario extends Libro{}

class DizionarioTecnico extends Dizionario{}

final class Romanzo extends Libro{}

public class Main {

	public static void main(String[] args) {
		
		
	}

}
