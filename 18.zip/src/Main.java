public class Main {

	public static void main(String[] args) {
		int valore=12;
		Integer x=Integer.valueOf(valore);
		Integer y=Integer.valueOf(100);
		Integer da_stringa=Integer.valueOf("100");
		int a=x;
		String nome="Samuele";
		System.out.println(12+valore+Integer.valueOf(100)+da_stringa);
	}

}
