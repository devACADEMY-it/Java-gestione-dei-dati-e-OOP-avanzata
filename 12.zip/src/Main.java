import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> frutti = new ArrayList<String>();
		LinkedList<String> animali = new LinkedList<String>();
		
		frutti.add("banana");
		frutti.add("mela");
		frutti.add("anguria");
		animali.add("cane");
		animali.add("gatto");
		animali.add("topo");
		
		List<String> lista=frutti;
		System.out.println(lista.get(1));
		
		lista=animali;
	    System.out.println(lista.get(1));
	}

}
