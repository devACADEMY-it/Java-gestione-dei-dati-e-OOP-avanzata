import java.util.ArrayList;

abstract class Persona{
	abstract void cosafaccio();
}


class Docente extends Persona{
	
	@Override
	void cosafaccio() {
		System.out.println("Sono un docente");
	}
}

class Studente extends Persona{
	
	@Override
	void cosafaccio() {
		System.out.println("Sono uno studente");
	}
}

public class Main {

	public static void main(String[] args) {
		ArrayList<Persona> persone=new ArrayList<Persona>();
		persone.add(new Docente());
		persone.add(new Studente());
		persone.add(new Docente());
		persone.add(new Docente());
		persone.add(new Studente());
		persone.add(new Studente());
		persone.add(new Studente());
		persone.add(new Studente());
		
		for (Persona p:persone)
			p.cosafaccio();
		
		
	}

}
