/*class Libro{
	private String titolo;
	private int pagine;
	private float prezzo;
	
	Libro(String titolo, int pagine, float prezzo){
		this.titolo=titolo;
		this.pagine=pagine;
		this.prezzo=prezzo;
	}
	
	public String titolo() {
		return titolo;
	}
	
	public int pagine() {
		return pagine;
	}
	
	public float prezzo() {
		return prezzo;
	}
	
	@Override
	public String toString() {
		return titolo+" ("+pagine+" pagine), "+prezzo+" euro";
	}
	
}*/

record Libro(String titolo, int pagine, float prezzo) {
	
	Libro(String titolo, int pagine, float prezzo){
		if (pagine<=0)
			throw new IllegalArgumentException();
		this.pagine=pagine;
		this.titolo=titolo;
		this.prezzo=prezzo;
	}
	
	float prezzoScontato() {
		return prezzo*0.8f;
	}
	
};

public class Main {

	public static void main(String[] args) {
		try {
			Libro un_libro=new Libro("Manuale di giardinaggio", 670, 45f);
		    System.out.println(un_libro);
		    System.out.println(un_libro.titolo()+" costa "+un_libro.prezzo()+" euro");
		    System.out.println(un_libro.titolo()+
		    		" costa scontato solo "+
		    		un_libro.prezzoScontato()+" euro");
		}
		catch(IllegalArgumentException iae) {
			System.out.println("Impossibile dichiarare un libro!");
		}
	}

}
