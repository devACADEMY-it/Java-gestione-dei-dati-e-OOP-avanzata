import java.util.*;

public class Main {

	public static void main(String[] args) {
		Set<String> frutti1=new HashSet<String>();
		Set<String> frutti2=new HashSet<String>();
		
		frutti1.add("banana");
		frutti1.add("mela");
		frutti1.add("kiwi");
		frutti1.add("anguria");
		
		frutti2.add("banana");
		frutti2.add("mela");
		frutti2.add("pera");
		
		// unione
		//frutti1.addAll(frutti2);
		
		// intersezione
		// frutti1.retainAll(frutti2);
		
		// differenza
		frutti1.removeAll(frutti2);
		
		System.out.println("Il risultato contiene "+frutti1.size()+" elementi");
		
		for (String frutto: frutti1)
			System.out.println(">> "+frutto);
	}

}
