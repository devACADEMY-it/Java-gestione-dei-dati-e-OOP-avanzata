interface Vendibile{
	
	static String descriviRegole() {
		return "Regole dell'azienda:\n"+
			   "- Acconto del 10%\n"+
			   "- Saldo entro 30 gg.";
	}
	
	default void vendiProdotto(){
		System.out.println("Venduto a 500 euro");
	}
	
}

class Prodotto implements Vendibile{
	
	@Override
	public void vendiProdotto() {
		System.out.println("Venduto a 1000 euro");
	}
	
}

public class Main {

	public static void main(String[] args) {
		System.out.println(Vendibile.descriviRegole());
		
		Prodotto prodotto = new Prodotto();
		prodotto.vendiProdotto();
		
	}

}
