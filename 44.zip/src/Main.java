import java.io.*;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Main {

	public static void main(String[] args) {
		try {
			// scrittura su file
			String nota="Questi sono i miei appunti";
			Path fileName=Path.of("nota.txt");
			Files.writeString(fileName, nota);
			
			// lettura su file
			String file_content=Files.readString(fileName);
			System.out.println(file_content);
		}
		catch(IOException io) {
			
		}
	}
}
