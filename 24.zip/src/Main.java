import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class NotValidException extends RuntimeException{}

class Automobile{
	private String targa;
	private LocalDate immatricolazione;
	
	Automobile(String targa, LocalDate immatricolazione){
		Pattern pattern=Pattern.compile("^[A-Z]{2}[0-9]{3}[A-Z]{2}$");
		Matcher match=pattern.matcher(targa);
		if (!match.find())
			throw new NotValidException();
		if (immatricolazione.isBefore(LocalDate.of(1990,1,1)) ||
				immatricolazione.isAfter(LocalDate.now()))
			throw new NotValidException();
	}
}

public class Main {

	public static void main(String[] args) {
		try {
			Automobile auto=new Automobile("df123XY", LocalDate.of(2022,1,12));
			System.out.println("Dati validi");
		}
		catch(NotValidException e) {
			System.out.println("Dati NON validi");
		}
	}

}
