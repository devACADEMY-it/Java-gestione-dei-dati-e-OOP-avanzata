import java.util.*;
import java.util.Map.Entry;

public class Main {

	public static void main(String[] args) {
		HashMap<String, String> capitali=new HashMap<String,String>();
		capitali.put("Italia", "Roma");
		capitali.put("Francia", "Parigi");
		capitali.put("Spagna", "Madrid");
		capitali.put("Grecia", "Atene");
		capitali.put("Portogallo", "Lisbona");
		
		System.out.println("Le entry sono "+capitali.size());
		System.out.println("Capitale della Grecia: "+capitali.get("Grecia"));
		
		System.out.println("CHIAVI:");
		for (String chiave: capitali.keySet())
			System.out.println(">> "+chiave);
		System.out.println();
		
		System.out.println("VALORI:");
		for (String valore: capitali.values())
			System.out.println(">> "+valore);
		System.out.println();
		
		System.out.println("ENTRY:");
		for (Entry<String,String> entry: capitali.entrySet())
			System.out.println(entry.getKey()+" : "+entry.getValue());
	}

}
